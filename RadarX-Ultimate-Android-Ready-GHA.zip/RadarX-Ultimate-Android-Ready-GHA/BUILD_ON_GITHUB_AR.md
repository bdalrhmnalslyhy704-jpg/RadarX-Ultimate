# بناء APK تلقائيًا عبر GitHub Actions

1. أنشئ Repository جديدًا على GitHub.
2. ارفع محتويات هذا المجلد كما هي.
3. افتح Actions ثم Workflow باسم **Build RadarX Android APK**.
4. اضغط **Run workflow**.
5. بعد نجاح البناء افتح الـWorkflow ثم Artifacts ونزّل `radarx-ultimate-debug-apk`.

الملف الناتج:
`app-debug.apk`

المشروع يستخدم Node 22 وJava 21 وAndroid API 36، ثم ينشئ مشروع Capacitor Android ويجري `assembleDebug`.

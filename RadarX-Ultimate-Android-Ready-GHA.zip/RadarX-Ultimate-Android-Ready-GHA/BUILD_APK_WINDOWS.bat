@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo RadarX Ultimate Android Build
 echo ==========================================
node --version
if errorlevel 1 goto :node_error
java -version
if errorlevel 1 goto :java_error
if not exist package-lock.json (
  echo Installing Capacitor dependencies...
  npm install
  if errorlevel 1 goto :npm_error
)
if not exist android (
  echo Adding Android platform...
  npx cap add android
  if errorlevel 1 goto :cap_error
)
echo Syncing web assets...
npx cap sync android
if errorlevel 1 goto :cap_error
echo Building DEBUG APK...
cd android
gradlew.bat assembleDebug
if errorlevel 1 goto :gradle_error
cd ..
echo.
echo BUILD SUCCESSFUL
echo APK: android\app\build\outputs\apk\debug\app-debug.apk
exit /b 0
:node_error
echo Node.js 22+ is required.
exit /b 1
:java_error
echo Java/JDK is required.
exit /b 1
:npm_error
echo npm install failed. Check Internet/DNS.
exit /b 1
:cap_error
echo Capacitor Android setup failed.
exit /b 1
:gradle_error
echo Gradle/Android SDK build failed. Check Android SDK + licenses.
exit /b 1

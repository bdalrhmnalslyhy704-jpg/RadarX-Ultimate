# RadarX Ultimate 4.32 — Android Ready

هذا المشروع يضع RadarX 4.32 FIXED FINAL داخل `www/index.html` ويستخدم Capacitor Android 8.5.2.

## المتطلبات
- Node.js 22+
- Java/JDK 21
- Android Studio أو Android SDK مع platform/build-tools اللازمة
- اتصال إنترنت لأول تثبيت للحزم وGradle/SDK

## البناء السريع على Windows
1. افتح المجلد.
2. شغّل `BUILD_APK_WINDOWS.bat`.
3. بعد نجاح البناء ستجد:
   `android/app/build/outputs/apk/debug/app-debug.apk`

## إعداد الصلاحيات
بعد تنفيذ `npx cap add android` افتح:
`android/app/src/main/AndroidManifest.xml`
وأضف:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.VIBRATE" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

## تحديث RadarX
استبدل `www/index.html` بالنسخة الجديدة ثم:
`npx cap sync android`

## Package ID
`com.radarx.app`

## ملاحظة التوقيع
`app-debug.apk` مناسب للاختبار والسideload. لتوزيع Release استخدم Android Studio → Generate Signed App Bundle / APK وأنشئ keystore خاصًا بك.
